SAE 1.01 : implémentation

Trinôme/trinomial : 	BERTOUT Baptiste
				DESMONS Hugo
				DORMAEL Louis



FR :

Pour compiler et executer le programme sur linux:

	- ouvrir un terminal
	- se diriger à l'endroit où se trouve le programme --> executer la commande : cd <chemin>
	- executer la commande ijavac pour compiler le programme --> ijavac nomDuProgramme.java
	- executer la commande ijava pour executer le programme compilé --> ijava nomDuProgramme ( attention à prendre celui 
	  avec une extension .class )
	- le programme s"execute, vous pouvez dès à présent coder, décoder les messages que vous voulez :)


Ce programme a été réaliser dans le cadre de la SAE 1.01 implémentation en travail d'équipe, chaque personne du trinôme a participé
équitablement au projet, et s'est investi dans sa réalisation




EN :

To compile and run the program on linux

	- open a terminal
	- go to the location of the program --> execute the command: cd <path>
	- run the ijavac command to compile the program --> ijavac programName.java
	- execute the ijava command to run the compiled program --> ijava programName ( be careful to take the one 
	  with a .class extension)
	- the program is executed, you can now code, decode the messages you want :)


This program was realized in the framework of the SAE 1.01 implementation in teamwork, each person of the trinomial participated
equally to the project, and invested in its realization

Translated with www.DeepL.com/Translator (free version)