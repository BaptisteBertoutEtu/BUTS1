class QCM{
    String question;
    String answer;
    String answer1;
    String answer2;
    String answer3;
}